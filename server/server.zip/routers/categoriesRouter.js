const express= require ('express');
const { addCategoryController, getAllCategories, updateCategory, deleteCategory, fetchCategoriesController } = require ('../controllers/categoriesController.js');

const router = express.Router();
router.route("/add").post(addCategoryController);
router.route("/all").get(fetchCategoriesController);

module.exports=router;