module.exports = {
    setupFiles: ["<rootDir>/src/setupTests.js"],
  };
  