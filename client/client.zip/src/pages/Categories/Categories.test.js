import React from 'react';
import { render, screen, waitFor, act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import axios from 'axios';
import Categories from './Categories';

jest.mock('axios');

const mockCategories = [
  { name: 'Category 1', description: 'Description 1' },
  { name: 'Category 2', description: 'Description 2' },
];

const addCategoryAPI = '/addCategory';
const fetchCategoriesAPI = '/fetchCategories';

describe('Categories component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('renders form elements', async () => {
    await act(async () => {
      render(<Categories />);
    });

    expect(screen.getByLabelText('Name:')).toBeInTheDocument();
    expect(screen.getByLabelText('Description:')).toBeInTheDocument();
    expect(screen.getByText('Add Category')).toBeInTheDocument();
  });

  test('submits the form successfully', async () => {
    axios.post.mockResolvedValueOnce();
    axios.get.mockResolvedValueOnce({ data: { categories: [] } });

    await act(async () => {
      render(<Categories />);
    });

    const nameInput = screen.getByLabelText('Name:');
    const descriptionInput = screen.getByLabelText('Description:');
    const submitButton = screen.getByText('Add Category');

    userEvent.type(nameInput, 'New Category');
    userEvent.type(descriptionInput, 'New Description');
    userEvent.click(submitButton);

    await waitFor(() => {
      expect(axios.post).toHaveBeenCalledWith(addCategoryAPI, {
        name: 'New Category',
        description: 'New Description',
      });
    });

    expect(axios.get).toHaveBeenCalledWith(fetchCategoriesAPI);
  });

  test('fetches categories successfully', async () => {
    axios.get.mockResolvedValueOnce({ data: { categories: mockCategories } });

    await act(async () => {
      render(<Categories />);
    });

    await waitFor(() => {
      mockCategories.forEach((category) => {
        expect(screen.getByText(`Name: ${category.name}`)).toBeInTheDocument();
        expect(screen.getByText(`Description: ${category.description}`)).toBeInTheDocument();
      });
    });
  });

  test('handles error when submitting the form', async () => {
    const errorMessage = 'Failed to add category';
    axios.post.mockRejectedValueOnce(new Error(errorMessage));
    axios.get.mockResolvedValueOnce({ data: { categories: [] } });

    await act(async () => {
      render(<Categories />);
    });

    const nameInput = screen.getByLabelText('Name:');
    const descriptionInput = screen.getByLabelText('Description:');
    const submitButton = screen.getByText('Add Category');

    userEvent.type(nameInput, 'New Category');
    userEvent.type(descriptionInput, 'New Description');
    userEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText(errorMessage)).toBeInTheDocument();
    });

    expect(axios.get).not.toHaveBeenCalled();
  });

  test('handles error when fetching categories', async () => {
    const errorMessage = 'Failed to fetch categories';
    axios.get.mockRejectedValueOnce(new Error(errorMessage));

    await act(async () => {
      render(<Categories />);
    });

    await waitFor(() => {
      expect(screen.getByText(errorMessage)).toBeInTheDocument();
    });
  });

  
});
