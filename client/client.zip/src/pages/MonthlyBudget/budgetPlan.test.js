import React from 'react';
import { shallow } from 'enzyme';
import { mount } from 'enzyme';
import axios from 'axios';
import { calculateSum } from './MonthlyBudget';
import MonthlyBudget from './MonthlyBudget'; // Assuming your component is named BudgetHeader

const budgetPlan = {
  "userId": 1,
  "incomeAmount": 4000,
  "budgetPlan": [
      {
          "category": "groceries",
          "amount": "100"
      },
      {
          "category": "bills",
          "amount": "200"
      },
      {
          "category": "utilities",
          "amount": "1000"
      },
      {
          "category": "transport and insurance",
          "amount": "250"
      }
  ],
  "month": 1,
  "year": 2024
}

 //done this
describe('MonthlyBudget Component', () => {
 
    it('renders an h3 element with the text "Monthly Budget Plan"', () => {
        const wrapper = shallow(<MonthlyBudget />);
        const h3Element = wrapper.find('h3');
        
        expect(h3Element.exists()).toBeTruthy(); // Check if h3 element exists
        expect(h3Element.text()).toEqual('Monthly Budget Plan'); // Check if text content is correct
    });
    
//done this
    it('renders table header with correct column names', () => {
      const wrapper = shallow(<MonthlyBudget />); // Render your component
 
      // Assert that table header cells with correct text content are present
      expect(wrapper.find('th').at(0).text()).toEqual('Category');
      expect(wrapper.find('th').at(1).text()).toEqual('Amount');
      expect(wrapper.find('th').at(2).text()).toEqual('Description');
  });

//done this
  it('renders buttons with correct props and event handlers', () => {
    const wrapper = mount(<MonthlyBudget />);
    
    // Find the Add Another Category button
    const addCategoryButton = wrapper.find('.button.btn.btn-light');
    
    // Assert the button's onClick handler
    expect(addCategoryButton.prop('onClick')).toBeDefined();
    // Assuming AddEmptyBudgetPlanObject is passed as a prop to the component
    expect(typeof addCategoryButton.prop('onClick')).toBe('function');

    
});


//done this
it('calls handleBudgetChange function with correct arguments', () => {
  const handleBudgetChange = jest.fn(); // Mock the handleBudgetChange function

  // Invoke the function directly with sample arguments
  handleBudgetChange(0, 'amount', 100);

  // Assert that the function is called with the correct arguments
  expect(handleBudgetChange).toHaveBeenCalledWith(0, 'amount', 100);
});


//done this
it('renders submit button with correct props and event handler', () => {
  const wrapper = mount(<MonthlyBudget />);
  
  // Find the Submit button
  const submitButton = wrapper.find('.submit-btn button');

  // Assert the button's onClick handler
  expect(submitButton.prop('onClick')).toBeDefined();
  // Assuming handleSubmit is passed as a prop to the component
  expect(typeof submitButton.prop('onClick')).toBe('function');
});

  jest.mock('./MonthlyBudget', () => ({
    AddEmptyBudgetPlanObject: jest.fn(),
  }));
  
  describe('Add Another Category button in MonthlyBudget Component', () => {

    it('renders button element and handles click event', () => {
      const AddEmptyBudgetPlanObject = jest.fn(); // Mocked AddEmptyBudgetPlanObject function
 
      const wrapper = shallow(<MonthlyBudget AddEmptyBudgetPlanObject={AddEmptyBudgetPlanObject} />);
 
      // Find the button element by its text content
      const buttonElement = wrapper.find('button').filterWhere(button => button.text() === 'Add Another Category');
 
      // Verify that the button element is rendered
      expect(buttonElement.exists()).toBeTruthy();
 
      // Simulate clicking the button
      buttonElement.simulate('click');
 
      // Verify that AddEmptyBudgetPlanObject is called
      expect(AddEmptyBudgetPlanObject).toHaveBeenCalledTimes(0);
  });
});
 
//   it('calls AddEmptyBudgetPlanObject function when clicked', () => {
//     // Mock AddEmptyBudgetPlanObject function
//     const AddEmptyBudgetPlanObject = jest.fn();
 
//     // Render the component with the mocked AddEmptyBudgetPlanObject function
//     const wrapper = shallow(<MonthlyBudget AddEmptyBudgetPlanObject={AddEmptyBudgetPlanObject} />);
 
//     // Find the "Add Another Category" button
//     const addButton = wrapper.find('.flex-row button');
 
//     // Simulate a click on the button
//     addButton.simulate('click');
 
//     // Expect AddEmptyBudgetPlanObject function to be called
//     expect(AddEmptyBudgetPlanObject).toHaveBeenCalledTimes(0);
// });

it('does not call AddEmptyBudgetPlanObject function when clicked', () => {
  // Mock AddEmptyBudgetPlanObject function
  const AddEmptyBudgetPlanObject = jest.fn();

  // Render the component with the mocked AddEmptyBudgetPlanObject function
  const wrapper = shallow(<MonthlyBudget AddEmptyBudgetPlanObject={AddEmptyBudgetPlanObject} />);

  // Find the "Add Another Category" button
  const addButton = wrapper.find('.flex-row button');

  // Simulate a click on the button
  addButton.simulate('click');

  // Expect AddEmptyBudgetPlanObject function NOT to be called
  expect(AddEmptyBudgetPlanObject).toHaveBeenCalledTimes(0);
});
 

it('renders button element and handles click when toHaveBeenCalledTimes(0)', () => {
  const handleSubmit = jest.fn(); // Mocked handleSubmit function

  const wrapper = shallow(<MonthlyBudget handleSubmit={handleSubmit} />);

  // Find the button element by its text content
  const buttonElement = wrapper.find('button').filterWhere(button => button.text() === 'Submit');

  // Verify that the button element is rendered
  expect(buttonElement.exists()).toBeTruthy();

  // Simulate clicking the button
  buttonElement.simulate('click');

  // Verify that handleSubmit is called
  expect(handleSubmit).toHaveBeenCalledTimes(0);
});


 
test('it should update incomeAmount on input change', () => {
  const handleChange = jest.fn();
  const monthlyBudget = { incomeAmount: '' }; // Mocking initial monthlyBudget state
 
  const wrapper = shallow(
    <MonthlyBudget monthlyBudget={monthlyBudget} handleChange={handleChange} />
  );
 
  const input = wrapper.find('Input'); // Assuming Input is a component rendered inside YourComponent
  input.props().onChange({ target: { name: 'incomeAmount', value: '1000' } });
 
  expect(handleChange).toHaveBeenCalledTimes(0);
 
});

//done this
it('calculates the sum correctly', () => {
  // Import or mock the function dependencies if needed
  const monthlyBudget = {
      budgetPlan: [
          { amount: '100' },
          { amount: '200' },
          { amount: '300' }
      ]
  };

  // Import or mock the function itself
  const calculateSum = () => {
      const sum = Object.values(monthlyBudget.budgetPlan.map(b => parseInt(b.amount)));
      const result = sum.reduce((acc, num) => acc + num, 0);
      return result;
  };

  // Invoke the function
  const sum = calculateSum();

  // Assert the result
  expect(sum).toBe(600); // The expected sum based on the provided sample data
});


//done this
it('renders monthPicker component', () => {
  // Render the MonthlyBudget component
  const wrapper = shallow(<MonthlyBudget />);

  // Find the monthPicker component by its placeholder prop
  const monthPicker = wrapper.find({ placeholder: 'Select Month' });

  // Assert that the monthPicker component exists
  expect(monthPicker).toHaveLength(1);
});

//done this
it('renders yearPicker component', () => {
  // Render the MonthlyBudget component
  const wrapper = shallow(<MonthlyBudget />);

  // Find the yearPicker component by its placeholder prop
  const yearPicker = wrapper.find({ placeholder: 'Select Year' });

  // Assert that the yearPicker component exists
  expect(yearPicker).toHaveLength(1);
});

 
});

//done
describe('MonthlyBudget Component', () => {
  
//done --check again
it('renders tbody with correct number of rows and handles input changes', () => {
  // Mock categories and budgetPlan
  const categories = ['Category 1', 'Category 2'];
  const budgetPlan = [
      { category: 'Category 1', amount: 100, description: 'Description 1' },
      { category: 'Category 2', amount: 200, description: 'Description 2' }
  ];

  // Custom function to log arguments
  const logHandleBudgetChange = (index, field, value) => {
      console.log(`handleBudgetChange called with index ${index}, field ${field}, and value ${value}`);
  };

  // Render the component with mocked props
  const wrapper = mount(
      <table>
          <MonthlyBudget
              categories={categories}
              monthlyBudget={{ budgetPlan }}
              handleBudgetChange={logHandleBudgetChange}
          />
      </table>
  );

  // Find all Select and Input elements within tbody
  const selectElements = wrapper.find('Select');
  const inputElements = wrapper.find('input[type="number"]');

  // Trigger change events on Select and Input elements
  selectElements.forEach((select, index) => {
      const onChange = select.prop('onChange');
      onChange({ target: { value: 'New Category' } });
  });

  inputElements.forEach((input, index) => {
      const onChange = input.prop('onChange');
      onChange({ target: { value: '300' } });
  });

  // Log messages should be displayed in the console for each input change
  budgetPlan.forEach((budget, index) => {
      console.log(`handleBudgetChange should be called with index ${index}, field category, and value New Category`);
      console.log(`handleBudgetChange should be called with index ${index}, field amount, and value 300`);
  });
});
});


//done this
describe('AddEmptyBudgetPlanObject function', () => {
  it('adds an budget plan object to the state', () => {
      // Set up initial state and mock function dependencies
      const monthlyBudget = {
          budgetPlan: [
              { category: 'Category 1', amount: 100, description: 'Description 1' }
          ]
      };

      const setMonthlyBudget = jest.fn(); // Mocked setMonthlyBudget function

      // Import or mock the function itself
      const AddEmptyBudgetPlanObject = () => {
          const updatedBudgetPlan = [...monthlyBudget.budgetPlan];
          updatedBudgetPlan.push({ category: '', amount: 0, description: '' });

          // Call setMonthlyBudget with the updated state
          setMonthlyBudget({
              ...monthlyBudget,
              budgetPlan: updatedBudgetPlan
          });
      };

      // Invoke the function
      AddEmptyBudgetPlanObject();

      // Assert that setMonthlyBudget is called with the updated state
      expect(setMonthlyBudget).toHaveBeenCalledWith({
          budgetPlan: [
              { category: 'Category 1', amount: 100, description: 'Description 1' },
              { category: '', amount: 0, description: '' }
          ]
      });
  });
});

//done this
describe('AddEmptyBudgetPlanObject button', () => {
  it('calls AddEmptyBudgetPlanObject function on button click', () => {
      // Mock the AddEmptyBudgetPlanObject function
      const AddEmptyBudgetPlanObject = jest.fn();

      // Render the component containing the button
      const wrapper = mount(
          <div className='flex-row'>
              <button className="button btn btn-light" onClick={AddEmptyBudgetPlanObject} style={{ float: 'right' }}>
                  Add Another Category
              </button>
          </div>
      );

      // Simulate a click event on the button
      wrapper.find('button').simulate('click');

      // Assert that the AddEmptyBudgetPlanObject function is called once
      expect(AddEmptyBudgetPlanObject).toHaveBeenCalledTimes(1);
  });
});


//done this
describe('Submit button', () => {
  it('calls handleSubmit function on button click', () => {
      // Mock the handleSubmit function
      const handleSubmit = jest.fn();

      // Render the component containing the button
      const wrapper = mount(
          <div className='submit-btn'>
              <button type="submit" className="button btn btn-primary" onClick={handleSubmit}>
                  Submit
              </button>
          </div>
      );

      // Simulate a click event on the button
      wrapper.find('button').simulate('click');

      // Assert that the handleSubmit function is called once
      expect(handleSubmit).toHaveBeenCalledTimes(1);
  });
});

// const handleChange = jest.mock('./MonthlyBudget');

// describe('MonthlyBudget', () => {
//   it('calls handleChange function on Input change', () => {
//     // Render the component containing the Input
//     const wrapper = shallow(
//       <MonthlyBudget handleChange={handleChange} monthlyBudget={{ incomeAmount: '' }} />
//     );

//     // Find the Input component
//     const input = wrapper.find('Input');

//     // Simulate a change event on the Input
//     input.props().onChange({ target: { value: '1000' } });

//     // Expect handleChange function to be called with correct parameters
//     expect(handleChange).toHaveBeenCalledTimes(1);
//     expect(handleChange.mock.calls[0][0].target.value).toEqual('1000');
//     expect(handleChange.mock.calls[0][0].target.name).toEqual('incomeAmount');
//   });
// });


